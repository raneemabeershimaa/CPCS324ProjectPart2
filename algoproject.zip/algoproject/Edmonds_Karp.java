package javaapplication24;

import java.util.*;

public class Edmonds_Karp {

    //BFS is used to get all the path possible from the source to the sink 
    public static boolean BFS(int Rgraph[][], int source, int sink, int parent[]) {

        int Ver = Rgraph[1].length, i = 0;

        // set all vertices as not visited
        boolean isVisited[] = new boolean[Ver];
        while (i < isVisited.length) {
            isVisited[i] = false;
            ++i;
        }

        /* 
          Create a queue implemented as linklist to keep track of the path , add source vertex to the queue and mark
          source vertex as visited
         */
        LinkedList<Integer> pathQueue = new LinkedList<>();
        pathQueue.add(source);
        isVisited[source] = true;
        //the source has no parent 
        parent[source] = -1;

        //traverse the vertices using BFS approche while there are verts in the queue   
        while (!pathQueue.isEmpty()) {
            //consider the head of the queue as the source
            int src = pathQueue.poll();
            for (int dest = 0; dest < Ver; dest++) {
                //if the destination has not been visited and there is an edge with a capacity between src & dest
                // add is to the queue and set it as visited , set the the parent of dest is the src
                if (isVisited[dest] == false && Rgraph[src][dest] > 0) {
                    pathQueue.add(dest);
                    parent[dest] = src;
                    isVisited[dest] = true;
                }
            }
        }
        //check if we reach the sink using the found path using BFS
        //  return true If we reached sink else return false

        return (isVisited[sink] == true);
    }//end of BFS

    /*
    (Edmonds-Karp,ford Fulkerson ) maximum-flow algorithm using BFS to find the maximum flow of the network,
     and the corresponding min-cut using DFS
     */
    public static void maximumFlowOfNetwork(int[][] graph, int source, int sink) {
        int u = 0, v = 0;

        //number of vertices
        int numberOfVart = graph[1].length;
        int[][] ResGraph = new int[numberOfVart][numberOfVart];
        /*
          Create a Residual graph with the same size as the original grapth and fill it with
          residual capacity   
         */

        while (u < numberOfVart) {
            v = 0;
            while (v < numberOfVart) {
                ResGraph[u][v] = graph[u][v];
                v++;
            }
            u++;
        }

        // parent array using to store path by BFS
        int parent[] = new int[numberOfVart];

        //initialize the max flow (no flow initially)
        int max_flow = 0;
        //------------------------------------------

        //while there is path from source to sink, set the flow direction "->" or "<-" and augment the flow  
        while (BFS(ResGraph, source, sink, parent)) {
            String path = "";
            v = sink;

            //initialize the max flow to infinite to find the maximum flow through the path
            int pathFlow = Integer.MAX_VALUE;
            while (v != source) {
                // set the flow direction and the source is the parent
                String direction = "←";
                u = parent[v];
                //update the path flow 
                pathFlow = Math.min(pathFlow, ResGraph[u][v]);

                if (graph[u][v] != 0) {
                    direction = "→";
                }
                path = direction + (v + 1) + path;

                v = parent[v];
            }
            //print the path flow 
            path = (v + 1) + path;
            System.out.printf(path + "  (flow " + pathFlow + ") \n");

            //update residual capacities of the edges and reverse edges along the path
            v = sink;
            while (v != source) {
                u = parent[v];
                ResGraph[u][v] -= pathFlow;
                ResGraph[v][u] += pathFlow;
                v = parent[v];
            }
            // Add path flow to maximum possible flow
            max_flow += pathFlow;

            System.out.println("Updated maximum possible flow: " + max_flow + "\n");

        }

        //print maximum possible flow
        System.out.println("The maximum possible flow is " + max_flow);
        System.out.println("\n----------------------------------------------- \n");
        System.out.println("The minimum cut Edges ");
        //to know if nodes is vesited or not
        boolean[] isVisited = new boolean[graph.length];
        //trverse the path with DFS to get the min-cut
        DFS(ResGraph, source, isVisited);

        // Print all edges from a vertex to other dest vertices 
        int totalCut = 0, i = 0, j;
        while (i < graph.length) {
            j = 0;
            while (j < graph.length) {
                //if there is an edge with weight between i ,j print it and add it to the mini cut
                if (graph[i][j] > 0 && isVisited[i] && !isVisited[j]) {
                    System.out.print((i + 1) + " → " + (j + 1));
                    System.out.println(" , Capacity = " + graph[i][j]);
                    //update the min cut  
                    totalCut += graph[i][j];

                    System.out.println("Updated min-cut capicity: " + totalCut + "\n");
                }
                j++;
            }
            i++;
        }
        //print final total mini cut capacity
        System.out.println("\n> The total min-cut capacity is " + totalCut + "\n");
    }

    //DFS is used to find the min-cut
    public static void DFS(int[][] Rgraph, int s, boolean[] visited) {
        visited[s] = true;
        int i = 0;
        //loop through graph to visit the nodes of a path 
        while (i < Rgraph.length) {
            if (Rgraph[s][i] > 0 && !visited[i]) {
                DFS(Rgraph, i, visited);
            }
            i++;
        }
    }

    public static void main(String[] args) throws java.lang.Exception {

        System.out.println("    -------------- CPCS324 Project - Question 2, Task1 ---------------");
        System.out.println("This program will implement the maximum flow based on Edmonds-Karp algorithm\n");

        //Design the Weighted Graph data type
        int NumOfverts = 6;
        WeightedGraph graph = new WeightedGraph(NumOfverts);
        int[][] Weighted_Graph = graph.make_Weighted_Graph(graph);

        //call maximumFlowOfNetwork method  
        maximumFlowOfNetwork(Weighted_Graph, 0, NumOfverts - 1);
    }

}
