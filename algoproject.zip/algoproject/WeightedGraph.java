package javaapplication24;

import java.util.*;

public class WeightedGraph {

    //number of vertices
    private int NumOfverts;

    //number of edges
    private int NumOfedges;

    //is Weighted Graph
    boolean isWeightedGraph;
    // Graph constructor  

    WeightedGraph(int vertices) {
        this.NumOfverts = vertices;

    }

    public int getNumOfverts() {
        return NumOfverts;
    }

    public void setNumOfverts(int NumOfverts) {
        this.NumOfverts = NumOfverts;
    }

    public int getNumOfedges() {
        return NumOfedges;
    }

    public void setNumOfedges(int NumOfedges) {
        this.NumOfedges = NumOfedges;
    }

    public boolean isIsWeightedGraph() {
        return true;
    }

    public void setIsWeightedGraph(boolean isWeightedGraph) {
        this.isWeightedGraph = isWeightedGraph;
    }

    public int[][] make_Weighted_Graph(WeightedGraph graph) {
        Scanner in = new Scanner(System.in);
        int NumOfverts = graph.getNumOfverts();
        int Weighted_Graph[][] = new int[NumOfverts][NumOfverts];

        for (int i = 0; i < NumOfverts; i++) {
            for (int j = 0; j < NumOfverts; j++) {
                System.out.println("Enter the Weight between vertex [" + (i + 1) + "] and [" + (j + 1) + "]");
                Weighted_Graph[i][j] = in.nextInt();
            }
        }
        
//        int Weighted_Graph[][]
//                = {{0, 2, 7, 0, 0, 0},
//                {0, 0, 0, 3, 4, 0},
//                {0, 0, 0, 4, 2, 0},
//                {0, 0, 0, 0, 0, 1},
//                {0, 0, 0, 0, 0, 5},
//                {0, 0, 0, 0, 0, 0}};

        return Weighted_Graph;

    }

}
