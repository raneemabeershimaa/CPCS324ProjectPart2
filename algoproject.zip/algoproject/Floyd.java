/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package floyd;

/**
 *
 * @author abeer
 */
public class Floyd {

    final static int Infinite = 999999, NumOfVertices = 10;

    public static void main(String[] args) {
        double startTime, endTime, runTime = 0;
        System.out.println("----------------------- CPCS324 Project - Phase2 -----------------------\n");
        System.out.println("----------------------- Floyd-Warshall Algorithm -----------------------\n");

        //weight matrix
        int graph[][] = {
            {0, 10, Infinite, Infinite, Infinite, 5, Infinite, Infinite, Infinite, Infinite},
            {Infinite, 0, 3, Infinite, 3, Infinite, Infinite, Infinite, Infinite, Infinite},
            {Infinite, Infinite, 0, 4, Infinite, Infinite, Infinite, 5, Infinite, Infinite},
            {Infinite, Infinite, Infinite, 0, Infinite, Infinite, Infinite, Infinite, 4, Infinite},
            {Infinite, Infinite, 4, Infinite, 0, Infinite, 2, Infinite, Infinite, Infinite},
            {Infinite, 3, Infinite, Infinite, Infinite, 0, Infinite, Infinite, Infinite, 2},
            {Infinite, Infinite, Infinite, 7, Infinite, Infinite, 0, Infinite, Infinite, Infinite},
            {Infinite, Infinite, Infinite, 4, Infinite, Infinite, Infinite, 0, 3, Infinite},
            {Infinite, Infinite, Infinite, Infinite, Infinite, Infinite, Infinite, Infinite, 0, Infinite},
            {Infinite, 6, Infinite, Infinite, Infinite, Infinite, 8, Infinite, Infinite, 0}
        };

        System.out.println("\t\t\tThe Wight Matrix:\n");

        startTime = System.currentTimeMillis();
        printMatrix(graph);
        floydWarshall(graph);
        endTime = System.currentTimeMillis();
        runTime = endTime - startTime;
        System.out.println("Total runtime is: " + runTime + " ms");
    }

    // Method to implemente floyd warshall algorithm
    public static void floydWarshall(int graph[][]) {

        //compute the distance matrix
        int i, j, k;
        for (k = 0; k < NumOfVertices; k++) {
            for (i = 0; i < NumOfVertices; i++) {
                for (j = 0; j < NumOfVertices; j++) {
                    if (graph[i][k] + graph[k][j] < graph[i][j]) {//find minimum 
                        graph[i][j] = graph[i][k] + graph[k][j]; //assign the min value
                    }
                }
            }
            if (k == NumOfVertices - 1) {//print the wight matrix (last iteration)
                System.out.println("----------------------------------------------------------------------------");
                System.out.println("\n\t\t\tD(" + (k + 1) + ") \"Distance Matrix:\" ");
                System.out.println("");
            } else {//print each intermediate matrix for every iteration
                System.out.println("----------------------------------------------------------------------------");
                System.out.println("\n\t\t\t\tD(" + (k + 1) + "):");
                System.out.println("");
            }
            printMatrix(graph);
        }
    }

    // Method to Print the matrix
    public static void printMatrix(int matrix[][]) {
        for (int i = 0; i < NumOfVertices; ++i) {
            for (int j = 0; j < NumOfVertices; ++j) {
                if (matrix[i][j] != Infinite) {
                    System.out.print(matrix[i][j] + "\t");
                } else {
                    System.out.print("∞\t");
                }
            }
            System.out.println(" ");
        }
        System.out.println("\n----------------------------------------------------------------------------\n");
    }
}
